import mongoose, { Schema, models, model } from "mongoose";

const VariantSchema = new Schema(
  {
    volume: {
      type: String,
      required: true,
    },

    price: {
      type: Number,
      required: true,
    },

    stock: {
      type: Number,
      default: 0,
    },
  },
  {
    _id: false,
  }
);

const ProductSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },

    slug: {
      type: String,
      unique: true,
      required: true,
    },

    brand: String,

    sku: String,

    featured: {
      type: Boolean,
      default: false,
    },

    bestSeller: {
      type: Boolean,
      default: false,
    },

    category: String,

    description: String,

    topNotes: String,

    heartNotes: String,

    baseNotes: String,

    image: String,

    images: [String],

    variants: [VariantSchema],

    rating: {
      type: Number,
      default: 5,
    },

    reviews: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

export default models.Product ||
  model("Product", ProductSchema);