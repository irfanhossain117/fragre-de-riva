import mongoose, { Schema, models, model } from "mongoose";

const OrderItemSchema = new Schema(
  {
    productId: {
      type: Schema.Types.ObjectId,
      ref: "Product",
    },

    name: String,

    image: String,

    volume: String,

    price: Number,

    quantity: Number,
  },
  {
    _id: false,
  }
);

const OrderSchema = new Schema(
  {
    customer: {
      name: {
        type: String,
        required: true,
      },

      phone: {
        type: String,
        required: true,
      },

      email: String,

      address: {
        type: String,
        required: true,
      },

      note: String,
    },

    items: [OrderItemSchema],

    subtotal: Number,

    deliveryCharge: Number,

    total: Number,

    paymentMethod: {
      type: String,
      default: "COD",
    },

    status: {
      type: String,
      enum: [
        "Pending",
        "Confirmed",
        "Packing",
        "Shipped",
        "Delivered",
        "Cancelled",
      ],
      default: "Pending",
    },
  },
  {
    timestamps: true,
  }
);

export default models.Order ||
  model("Order", OrderSchema);